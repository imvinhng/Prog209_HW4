var express = require('express');
var router = express.Router();

/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('grass_index', { title: 'The GrassShop ' });

});

/* GET users listing. */
router.get('/help', function(req, res, next) {
  res.render('grass_help', { title: 'GrassShop Help' });
});

/* GET users listing. */
router.get('/register', function(req, res, next) {
  res.render('grass_register', { title: 'GrassShop Register' });
});

/* GET users listing. */
router.get('/signin', function(req, res, next) {
  res.render('grass_signin', { title: 'GrassShop Sign-in' });
});




module.exports = router;
