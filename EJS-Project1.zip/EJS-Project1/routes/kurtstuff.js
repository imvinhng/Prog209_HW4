var express = require('express');
var router = express.Router();

/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('kurtsflowershop', { title: 'Kurts FlowerShop Title' });
 // res.send('Welcome to Kurts Flower shop');
});

/* GET users listing. */
router.get('/help', function(req, res, next) {
  res.render('kurtshelp', { title: 'FlowerShop Help' });
});

/* GET users listing. */
router.get('/register', function(req, res, next) {
  res.render('kurtsregister', { title: 'FlowerShop Register' });
});


module.exports = router;
